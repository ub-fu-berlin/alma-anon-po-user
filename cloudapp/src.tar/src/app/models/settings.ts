export interface Settings {
      showValue: boolean,
      showApi: boolean,
      anonymous: string,
      language: string
    }
